//
//  TPRRetweetsOperation.m
//  Tweepr
//
//  Created by Pedro Remedios on 31/05/2013.
//
//

#import "TPRRetweetsOperation.h"

@interface TPRRetweetsOperation ()

@property (nonatomic, strong) UserTweet *tweet;

@end

@implementation TPRRetweetsOperation

- (id)initWithUserID:(NSString *)userID tweet:(UserTweet *)tweet
{
    if ((self = [super initWithUserID:userID]))
    {
        self.tweet = tweet;
    }
    return self;
}

- (void)start
{
    [self willChangeValueForKey:@"isExecuting"];
    self.statusExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];
    
    [[[NetworkManager sharedInstance] twitterAPI] getStatusesRetweetsForID:self.tweet.tweetId count:@"100" trimUser:@0 successBlock:^(NSArray *statuses) {
        BOOL done = YES;
        dispatch_async(dispatch_get_main_queue(), ^{
            
            DataManager *dataManager = [DataManager sharedInstance];
            
            [dataManager updateRetweetsOfTweet:[self tweet]
                                    fullValues:statuses
                                     inContext:[dataManager mainThreadContext]];
            
            NSLog(@"Notification didFetchUserTweetsNotification");
            [[NSNotificationCenter defaultCenter] postNotificationName:didFetchUserTweetsNotification object:self];
            
        });
        
        if (done)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self willChangeValueForKey:@"isExecuting"];
                [self willChangeValueForKey:@"isFinished"];
                self.statusExecuting = NO;
                self.statusFinished = YES;
                [self didChangeValueForKey:@"isExecuting"];
                [self didChangeValueForKey:@"isFinished"];
                
            });
        }
    } errorBlock:^(NSError *error) {
        NSLog(@"%@", error);
    }];
}

@end
