//
//  TPRMentionsOperation.m
//  Tweepr
//
//  Created by Pedro Remedios on 14/06/2013.
//
//

#import "TPRMentionsOperation.h"

@implementation TPRMentionsOperation

- (void)start {
    [self willChangeValueForKey:@"isExecuting"];
    self.statusExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];
    [self getMentionsOlderThan:nil];
}

- (void)getMentionsOlderThan:(NSString *)maxId
{
    NSLog(@"Mentions: %@", maxId);
    
    [[[NetworkManager sharedInstance] twitterAPI] getStatusesMentionTimelineWithCount:@"200" sinceID:nil maxID:maxId trimUser:@0 contributorDetails:nil includeEntities:@0 successBlock:^(NSArray *statuses) {
        BOOL done = YES;
        dispatch_async(dispatch_get_main_queue(), ^{
            
            DataManager *dataManager = [DataManager sharedInstance];
            
            [dataManager updateUserMentions:statuses
                                  inContext:[dataManager mainThreadContext]];
            
        });
        NSDictionary *maxUser = [statuses lastObject];
        NSString *nextId = maxUser[@"id_str"];
        if (nextId.length && ![maxId isEqualToString:nextId]) {
            done = NO;
            [self getMentionsOlderThan:nextId];
        }
        
        if (done) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self willChangeValueForKey:@"isExecuting"];
                [self willChangeValueForKey:@"isFinished"];
                self.statusExecuting = NO;
                self.statusFinished = YES;
                [self didChangeValueForKey:@"isExecuting"];
                [self didChangeValueForKey:@"isFinished"];
            });
        }
    } errorBlock:^(NSError *error) {
        NSLog(@"%@", error);
    }];
}

@end
