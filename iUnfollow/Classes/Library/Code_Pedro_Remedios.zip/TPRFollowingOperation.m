//
//  TPRFollowingOperation.m
//  Tweepr
//
//  Created by Pedro Remedios on 18/05/2013.
//
//

#import "TPRFollowingOperation.h"

@implementation TPRFollowingOperation

- (void)start {
    [self willChangeValueForKey:@"isExecuting"];
    self.statusExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];
    [self getFollowingWithCursor:@"-1"];
}

- (void)getFollowingWithCursor:(NSString *)cursor
{
    BTITrackingLog(@">>> Entering <%p> %s <<<", self, __PRETTY_FUNCTION__);
    
    NSLog(@"Following: %@", cursor);
    
    [[[NetworkManager sharedInstance] twitterAPI] getFriendsIDsForUserID:self.userId orScreenName:nil cursor:cursor count:@"" successBlock:^(NSArray *ids, NSString *previousCursor, NSString *nextCursor) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            DataManager *dataManager = [DataManager sharedInstance];
            [dataManager updateFriendshipStatusWithIds:ids
                                             followers:NO
                                             inContext:[dataManager mainThreadContext]];
            
            if (nextCursor && ![nextCursor isEqualToString:@"0"])
            {
                [self getFollowingWithCursor:nextCursor];
            }
            else
            {
                [self willChangeValueForKey:@"isExecuting"];
                [self willChangeValueForKey:@"isFinished"];
                self.statusExecuting = NO;
                self.statusFinished = YES;
                [self didChangeValueForKey:@"isExecuting"];
                [self didChangeValueForKey:@"isFinished"];
            }
            
        });

    } errorBlock:^(NSError *error) {
        NSLog(@"%@", error);
    }];
    BTITrackingLog(@"<<< Leaving  <%p> %s >>>", self, __PRETTY_FUNCTION__);
}

@end
