//
//  TPRTimelineOperation.m
//  Tweepr
//
//  Created by Pedro Remedios on 08/06/2013.
//
//

#import "TPRTimelineOperation.h"

#import "TPRUpdateUserTweetsOperation.h"

@implementation TPRTimelineOperation


- (void)start
{
	BTITrackingLog(@">>> Entering <%p> %s <<<", self, __PRETTY_FUNCTION__);

    [self willChangeValueForKey:@"isExecuting"];
    self.statusExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];

    [self getTweetsOlderThan:nil];

	BTITrackingLog(@"<<< Leaving  <%p> %s >>>", self, __PRETTY_FUNCTION__);
}

- (void)getTweetsOlderThan:(NSString *)maxId
{
    NSLog(@"Timeline: %@", maxId);
    
    [[[NetworkManager sharedInstance] twitterAPI] getStatusesUserTimelineForUserID:self.userId screenName:nil sinceID:nil count:@"100" maxID:maxId trimUser:@YES excludeReplies:nil contributorDetails:nil includeRetweets:@YES successBlock:^(NSArray *statuses) {
        BOOL done = YES;
        dispatch_async(dispatch_get_main_queue(), ^{
            
            TPRUpdateUserTweetsOperation *operation = [[TPRUpdateUserTweetsOperation alloc] initWithUserTweets:statuses];
            [[[DataManager sharedInstance] operationQueue] addOperation:operation];
            //                [[DataManager sharedInstance] updateUserTweets:JSON];
            
        });
        
        NSDictionary *maxUser = [statuses lastObject];
        NSString *nextId = [maxUser[@"id_str"] description];
        if (nextId.length && ![maxId isEqualToString:nextId])
        {
            done = NO;
            [self getTweetsOlderThan:nextId];
        }
        
        if (done)
        {
            dispatch_async(dispatch_get_main_queue(), ^{

                [self willChangeValueForKey:@"isExecuting"];
                [self willChangeValueForKey:@"isFinished"];
                self.statusExecuting = NO;
                self.statusFinished = YES;
                [self didChangeValueForKey:@"isExecuting"];
                [self didChangeValueForKey:@"isFinished"];

            });
        }
    } errorBlock:^(NSError *error) {
        NSLog(@"%@", error);
    }];
}

@end
