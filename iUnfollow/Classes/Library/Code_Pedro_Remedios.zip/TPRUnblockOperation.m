//
//  TPRUnblockOperation.m
//  Tweepr
//
//  Created by Pedro Remedios on 04/06/2013.
//
//

#import "TPRUnblockOperation.h"
#import "TwitterUser.h"

@interface TPRUnblockOperation ()

@property (nonatomic, strong) TwitterUser *user;

@end

@implementation TPRUnblockOperation

- (id)initWithTwitterUser:(TwitterUser *)user userID:(NSString *)userID {
    if ((self = [super initWithUserID:userID])) {
        self.user = user;
    }
    return self;
}

- (void)start
{
    [self willChangeValueForKey:@"isExecuting"];
    self.statusExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];
    
    [[[NetworkManager sharedInstance] twitterAPI] postBlocksDestroyWithScreenName:self.user.screenName orUserID:self.user.identifier includeEntities:@0 skipStatus:@1 successBlock:^(NSDictionary *user) {
        [self willChangeValueForKey:@"isExecuting"];
        [self willChangeValueForKey:@"isFinished"];
        self.statusExecuting = NO;
        self.statusFinished = YES;
        [self didChangeValueForKey:@"isExecuting"];
        [self didChangeValueForKey:@"isFinished"];
        NSLog(@"Unblocked user: %@", self.user.screenName);
    } errorBlock:nil];
}

@end
