//
//  TPRUnfollowOperation.m
//  Tweepr
//
//  Created by Pedro Remedios on 11/05/2013.
//
//

#import "TPRUnfollowOperation.h"

@interface TPRUnfollowOperation ()

@property (nonatomic, strong) TwitterUser *user;

@end

@implementation TPRUnfollowOperation

- (id)initWithTwitterUser:(TwitterUser *)user {
    if ((self = [super initWithUserID:user.identifier])) {
        self.user = user;
    }
    return self;
}

- (void)start
{
    [self willChangeValueForKey:@"isExecuting"];
    self.statusExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];

    [[[NetworkManager sharedInstance] twitterAPI] postFriendshipsDestroyScreenName:self.user.screenName orUserID:self.user.identifier successBlock:^(NSDictionary *unfollowedUser) {
        [self willChangeValueForKey:@"isExecuting"];
        [self willChangeValueForKey:@"isFinished"];
        self.statusExecuting = NO;
        self.statusFinished = YES;
        [self didChangeValueForKey:@"isExecuting"];
        [self didChangeValueForKey:@"isFinished"];
        NSLog(@"Unfollowed user: %@", self.user.screenName);
    } errorBlock:^(NSError *error) {
        NSLog(@"Unable to follow user %@: %@", self.user.screenName, error.localizedDescription);
    }];
}

@end
