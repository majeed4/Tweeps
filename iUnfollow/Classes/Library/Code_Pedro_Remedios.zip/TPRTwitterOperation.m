//
//  TPRTwitterOperation.m
//  Tweepr
//
//  Created by Pedro Remedios on 18/05/2013.
//
//

#import "TPRTwitterOperation.h"

@implementation TPRTwitterOperation

- (id)initWithUserID:(NSString *)userID {
    if ((self = [super init])) {
        self.userId = userID;
        self.statusExecuting = NO;
        self.statusFinished = NO;
    }
    return self;
}

- (BOOL)isConcurrent {
    return YES;
}

- (BOOL)isExecuting {
    return self.statusExecuting;
}

- (BOOL)isFinished {
    return self.statusFinished;
}

-(void)setStatusExecuting:(BOOL)statusExecuting
{
    [self willChangeValueForKey:@"isExecuting"];
    _statusExecuting = statusExecuting;
    [self didChangeValueForKey:@"isExecuting"];
}

-(void)setStatusFinished:(BOOL)statusFinished
{
    [self willChangeValueForKey:@"isFinished"];
    _statusFinished = statusFinished;
    [self didChangeValueForKey:@"isFinished"];
}


@end
