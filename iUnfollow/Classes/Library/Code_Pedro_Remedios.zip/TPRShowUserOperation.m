//
//  TPRShowUserOperation.m
//  Tweepr
//
//  Created by Pedro Remedios on 12/06/2013.
//
//

#import "TPRShowUserOperation.h"

@interface TPRShowUserOperation ()

@property (nonatomic, strong) TwitterUser *user;

@end

@implementation TPRShowUserOperation

- (id)initWithTwitterUser:(TwitterUser *)user userID:(NSString *)userID {
    if ((self = [super initWithUserID:userID])) {
        self.user = user;
    }
    return self;
}

- (void)start
{
    BTITrackingLog(@">>> Entering <%p> %s <<<", self, __PRETTY_FUNCTION__);
    
    [self willChangeValueForKey:@"isExecuting"];
    self.statusExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];
    
    __weak TPRShowUserOperation *weakSelf = self;
    void(^finishOperation)(void) = ^{
        
        [weakSelf willChangeValueForKey:@"isExecuting"];
        [weakSelf willChangeValueForKey:@"isFinished"];
        weakSelf.statusExecuting = NO;
        weakSelf.statusFinished = YES;
        [weakSelf didChangeValueForKey:@"isExecuting"];
        [weakSelf didChangeValueForKey:@"isFinished"];
        
    };
    
    [[[NetworkManager sharedInstance] twitterAPI] getUsersShowForUserID:self.user.identifier orScreenName:self.user.screenName includeEntities:@0 successBlock:^(NSDictionary *user) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            DataManager *dataManager = [DataManager sharedInstance];
            [dataManager updateFollowingTwitterUsersWithArraysOfDictionary:@[user]
                                                                 inContext:[dataManager mainThreadContext]];
            
            finishOperation();
        });
    } errorBlock:^(NSError *error) {
        finishOperation();
    }];
}

@end
