//
//  TPRFollowersOperation.m
//  Tweepr
//
//  Created by Pedro Remedios on 18/05/2013.
//
//

#import "TPRFollowersOperation.h"

@implementation TPRFollowersOperation


- (void)start
{
	BTITrackingLog(@">>> Entering <%p> %s <<<", self, __PRETTY_FUNCTION__);

    [self willChangeValueForKey:@"isExecuting"];
    self.statusExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];
    [self getFollowersWithCursor:@"-1"];

	BTITrackingLog(@"<<< Leaving  <%p> %s >>>", self, __PRETTY_FUNCTION__);
}

- (void)getFollowersWithCursor:(NSString *)cursor
{
    BTITrackingLog(@">>> Entering <%p> %s <<<", self, __PRETTY_FUNCTION__);
    
    NSLog(@"Followers: %@", cursor);

    __weak TPRFollowersOperation *weakSelf = self;
    void(^finishOperation)(void) = ^{
        
        [weakSelf willChangeValueForKey:@"isExecuting"];
        [weakSelf willChangeValueForKey:@"isFinished"];
        weakSelf.statusExecuting = NO;
        weakSelf.statusFinished = YES;
        [weakSelf didChangeValueForKey:@"isExecuting"];
        [weakSelf didChangeValueForKey:@"isFinished"];
        
    };
    
    [[[NetworkManager sharedInstance] twitterAPI] getFollowersIDsForUserID:self.userId orScreenName:nil cursor:cursor count:nil successBlock:^(NSArray *followersIDs, NSString *previousCursor, NSString *nextCursor) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            DataManager *dataManager = [DataManager sharedInstance];
            
            [dataManager updateFriendshipStatusWithIds:followersIDs
                                             followers:YES
                                             inContext:[dataManager mainThreadContext]];
            
        });
        
        if (nextCursor && ![nextCursor isEqualToString:@"0"])
        {
            [self getFollowersWithCursor:nextCursor];
        }
        else
        {
            finishOperation();
        }


    } errorBlock:^(NSError *error) {
        NSLog(@"%@", error);
        
        finishOperation();
    }];
    
    BTITrackingLog(@"<<< Leaving  <%p> %s >>>", self, __PRETTY_FUNCTION__);
    
}

@end
